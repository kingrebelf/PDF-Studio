# PDF Studio

**Read it. Sign it. Make it yours.**

A calm, capable PDF reader and editor for Windows, macOS and Linux. It opens instantly, keeps
everything on your machine, and puts the editing tools behind a mode switch so the reading view
stays quiet.

![PDF Studio welcome screen](docs/screenshots/01-welcome.png)

## Two apps in one window

PDF Studio has two clearly separate modes, and the interface changes with them.

### View — read without noise

- Continuous, smooth page scrolling with page thumbnails and a document outline
- Text selection and copy, plus full-document search with match count and jump-to-match
- Zoom, fit page, fit width, page jump, keyboard and trackpad navigation
- **Dark paper** mode that inverts the page for late-night reading (separate from the app theme)
- Print, save, save a copy, and reopen recent files
- Opens password-protected PDFs with a password prompt
- Remembers your zoom, fit mode, theme and recent files between sessions

![PDF Studio viewer](docs/screenshots/02-viewer.png)

### Edit — everything else

A tool rail on the left, contextual options across the top, and a properties inspector on the
right. Every object can be selected, moved, resized, restyled, duplicated, reordered or deleted.

![PDF Studio editor](docs/screenshots/03-editor.png)

**Mark up**

- Highlight, underline and strikethrough with a palette of soft colours
- Freehand pen and highlighter with adjustable width and colour
- Shapes: rectangle, ellipse, line and arrow, with stroke and fill
- Text boxes with font, size, line height, alignment, bold and colour
- Sticky notes, preset stamps (Approved, Reviewed, Draft, Confidential) and date stamps
- Images from disk, whiteout blocks and a true redaction tool
- Eraser for annotations

**Sign**

- Draw a signature with a mouse, trackpad or pen
- Type a signature rendered in Great Vibes, or upload a photo of one
- Capture a signature with the camera
- Signatures are saved locally and can be reused without redrawing
- Place a **“Sign here”** box with a custom label for someone else to sign later

![Signature dialog](docs/screenshots/04-signature.png)

**Forms**

- Detects text fields, checkboxes, radio groups and dropdowns
- Fill them in place, then optionally flatten them into the page on save

**Pages and documents**

- Rotate, reorder, duplicate, insert, extract and delete pages
- Drag thumbnails to reorder, or use the page manager for batch work
- Merge another PDF into the open one
- Watermarks, headers and footers, and Bates numbering
- Compress a document to images when you need a smaller file
- Edit title, author, subject and keywords
- Export the document's text, or export every page as a PNG image

![Page manager](docs/screenshots/05-pages.png)

**Search and dark reading**

![Search](docs/screenshots/06-search.png)

![Dark theme](docs/screenshots/07-dark.png)

## Install and run

### Download a build

Unzip `PDF-Studio-1.0.0.zip` and open the `builds/` folder for your platform. The full source is in
`source/` alongside it.

| Platform | Folder | Run |
| --- | --- | --- |
| Windows x64 | `PDF Studio-win32-x64` | `PDF Studio.exe` (portable — no installer needed) |
| Linux x64 | `PDF Studio-linux-x64` | `./PDF\ Studio` |
| macOS (Apple silicon) | `PDF Studio-darwin-arm64` | `PDF Studio.app` |
| macOS (Intel) | `PDF Studio-darwin-x64` | `PDF Studio.app` |

The builds are unsigned. Windows SmartScreen may ask for confirmation the first time, and macOS
Gatekeeper may require right-click → **Open** (or `xattr -dr com.apple.quarantine "PDF Studio.app"`).

### Run from source

```bash
npm install
npm start
```

Requires Node.js 18 or newer. The app has no runtime npm dependencies — PDF.js, pdf-lib and the
signature font are vendored inside `app/`, so it also runs offline.

### Static checks

```bash
npm run check
```

This parses every ES module, verifies that every named import resolves, and checks that all
vendored files and local assets referenced by `index.html` exist. It is the same check CI runs.

### Build distributables

```bash
npm run package:win        # Windows x64 portable folder
npm run package:linux      # Linux x64
npm run package:mac        # macOS arm64
npm run package:mac-intel  # macOS x64
npm run package:all        # all of the above
```

Output lands in `release/`. Packaging is done with
[`@electron/packager`](https://github.com/electron/packager) and produces portable folders rather
than installers, which keeps the project dependency-light and cross-platform from one machine.

## Keyboard shortcuts

| Action | Shortcut |
| --- | --- |
| Open | `Ctrl/Cmd + O` |
| Save | `Ctrl/Cmd + S` |
| Save a copy | `Ctrl/Cmd + Shift + S` |
| Print | `Ctrl/Cmd + P` |
| Find | `Ctrl/Cmd + F` |
| Undo / redo | `Ctrl/Cmd + Z` / `Ctrl/Cmd + Shift + Z` (or `Ctrl/Cmd + Y`) |
| Zoom in / out / actual size | `+` / `−` / `0` |
| Select all text on the page | `Ctrl/Cmd + A` |
| Delete selected object | `Delete` / `Backspace` |
| Duplicate selected object | `Ctrl/Cmd + D` |
| Nudge selected object | Arrow keys (`Shift` for 10 pt) |
| Switch tools | `V T N I H U K D S G Y R F P E` |
| Pan the page | `Space` + drag |
| Zoom at the pointer | `Ctrl/Cmd` + wheel |
| Close search, menu, or deselect | `Esc` |

**Edit → Keyboard shortcuts** in the `···` menu opens the full in-app shortcut sheet.

## How saving works

Annotations are overlays while you work and are written into the PDF when you save. Highlights,
ink, text, stamps, signatures and form values are drawn as vector content where possible, so text
stays selectable and the file stays small.

Two cases need a different treatment:

- **Redaction** must remove the underlying content, not cover it. Pages containing redactions are
  rendered and re-embedded, so the original text and images beneath the block are gone.
- **Rotated pages** are rasterised so annotations land exactly where you placed them regardless of
  the page's rotation.

If you would rather keep a document's interactive form fields, turn off **Flatten on save** in the
Forms tool options.

## Privacy

PDF Studio does not have accounts, telemetry, analytics or network requests. Documents are read
from disk and written back to disk; signatures and preferences live in local storage on your
machine. The camera is only opened when you choose the Camera tab in the signature dialog.

## Project structure

```
main.js                 Electron main process: window, app:// protocol, dialogs, printing
preload.js              Narrow IPC bridge exposed to the renderer
app/
  index.html            Application shell
  css/app.css           All styling (light and dark themes, print styles)
  js/
    app.js              Boot, chrome, actions, shortcuts, close flow
    workspace.js        PDF.js loading, rendering, text layer, search, thumbnails
    editing.js          Canvas interactions, tools, text editing, placement
    paint.js            Shared overlay and form painting
    docops.js           Save pipeline, page operations, export, print
    docops-extra.js     Watermarks, headers/footers, Bates, compression
    dialogs-doc.js      Page manager and document tool dialogs
    signature.js        Draw/type/upload/camera signatures and saved signatures
    inspector.js        Object properties and document panels
    toolbar.js          Tool rail and contextual options
    state.js            State, palettes, preferences, recent files
    history.js          Undo/redo snapshots
    ui.js               Modals, menus, toasts, dialogs
    icons.js            Inline SVG icon set
  vendor/
    pdfjs/              PDF.js 4.10.38 (runtime, worker, cmaps, standard fonts)
    pdflib/             pdf-lib 1.17.1 (ES module build)
  assets/               Sample PDF, signature font and its licence, app icon
build/                  Icon source and generated .png/.ico/.icns
scripts/                Static check and sample PDF generator
docs/screenshots/       Screenshots used in this README
.github/workflows/      CI build for Windows, Linux and macOS
```

## Tech

- [Electron](https://www.electronjs.org/) with `contextIsolation` on and `nodeIntegration` off
- A custom `app://` protocol for the renderer, with a strict Content-Security-Policy
- [PDF.js](https://mozilla.github.io/pdf.js/) for rendering, text extraction and search
- [pdf-lib](https://pdf-lib.js.org/) for editing, page operations and flattening
- Plain ES modules and CSS — no bundler, no framework, no build step for the renderer

## Licence

MIT — see [LICENSE](LICENSE).

Bundled third-party components keep their own licences:

- PDF.js — Apache-2.0 (`app/vendor/pdfjs/`)
- pdf-lib — MIT (`app/vendor/pdflib/`)
- Great Vibes font — SIL Open Font License 1.1 (`app/assets/GreatVibes-OFL.txt`)
- Electron and Chromium — MIT and BSD-style licences (included in each packaged build)

The sample document (`app/assets/sample.pdf`) is fictional and generated by
`scripts/make-sample.mjs`.
